async function fetchDashboardData() {
    try {
        const response = await fetch('/api/dashboard');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();

        // Update follower and subscriber counts
        document.getElementById('followerCount').innerText = data.followers;
        document.getElementById('subscriberCount').innerText = data.subscribers;

        // Update progress bars
        const followerProgress = document.getElementById('followerProgress');
        const subscriberProgress = document.getElementById('subscriberProgress');

        const followerGoal = data.goals.followers;
        const subscriberGoal = data.goals.subscribers;

        const followerPercentage = (data.followers / followerGoal) * 100;
        const subscriberPercentage = (data.subscribers / subscriberGoal) * 100;

        followerProgress.style.width = `${followerPercentage}%`;
        subscriberProgress.style.width = `${subscriberPercentage}%`;

        // Hide counters if disabled in config
        if (!data.options.showFollowers) {
            document.getElementById('followerCounter').style.display = 'none';
        }
        if (!data.options.showSubscribers) {
            document.getElementById('subscriberCounter').style.display = 'none';
        }
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Fetch and display server IP as Widget URL
    fetch('/api/server-ip')
        .then(response => response.json())
        .then(data => {
            document.getElementById('widgetUrl').value = `http://${data.ip}:3000`; // Append port if needed
        })
        .catch(error => {
            console.error('Error fetching server IP:', error);
        });

    // Load other configurations and set up event listeners...
});


// Fetch dashboard data every 5 seconds
setInterval(fetchDashboardData, 5000);
fetchDashboardData(); // Initial fetch
