const express = require('express');
const axios = require('axios');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the public directory
app.use(express.static('public'));
app.use(express.json()); // Middleware to parse JSON

// Load configuration from JSON file
let config = JSON.parse(fs.readFileSync('config.json', 'utf8'));

// Endpoint to fetch data for the dashboard
app.get('/api/dashboard', async (req, res) => {
    if (!config.apiUrl) {
        return res.status(400).send('API URL not set. Please set your Rumble API URL in the dashboard.');
    }

    try {
        const response = await axios.get(config.apiUrl); // Use the complete API URL
        const data = response.data;

        const followerCount = data.followers.num_followers;
        const subscriberCount = data.subscribers.num_subscribers;

        res.json({ 
            followers: followerCount, 
            subscribers: subscriberCount, 
            goals: config.goals,
            options: config.options
        });
    } catch (error) {
        console.error('Error fetching data from Rumble API:', error);
        res.status(500).send('Error fetching data');
    }
});

// Endpoint to get the current configuration
app.get('/api/config', (req, res) => {
    res.json(config);
});

// Endpoint to update the configuration
app.post('/api/update-config', (req, res) => {
    const newConfig = req.body;
    fs.writeFileSync('config.json', JSON.stringify(newConfig, null, 2));
    config = newConfig; // Update the in-memory config
    res.send('Configuration updated successfully!');
});

// Serve the dashboard UI
app.get('/dashboard', (req, res) => {
    res.sendFile(__dirname + '/dashboardui.html');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
