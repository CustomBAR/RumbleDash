const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto'); // Required for unique user IDs
const app = express();
const os = require('os');
const PORT = process.env.PORT || 9000;

// Function to get the server's internal IP address
function getServerIP() {
    const networkInterfaces = os.networkInterfaces();
    for (let interfaceKey in networkInterfaces) {
        const networkInterface = networkInterfaces[interfaceKey];
        for (let i = 0; i < networkInterface.length; i++) {
            const address = networkInterface[i];
            if (address.family === 'IPv4' && !address.internal) {
                return address.address; // Return the internal IP address
            }
        }
    }
    return 'localhost'; // Fallback to localhost if no internal IP is found
}

// Endpoint to return the server's internal IP and port
app.get('/api/server-ip', (req, res) => {
    const internalIP = getServerIP();
    res.json({
        ip: internalIP,
        port: PORT
    });
});

// Serve static files from the public directory
app.use(express.static('public'));
app.use(express.static('widgets'));
app.use(express.json()); // Middleware to parse JSON
app.use(express.urlencoded({ extended: true })); // Middleware to parse URL-encoded data

// Load configuration from JSON file
let config = {};
try {
    config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
    validateConfig(config); // Ensure the config is valid
} catch (error) {
    console.error('Error loading configuration:', error.message);
}

function validateConfig(config) {
    if (!config.apiUrl || typeof config.apiUrl !== 'string') {
        throw new Error('Invalid API URL in configuration');
    }
    if (!config.likesApiUrl || typeof config.likesApiUrl !== 'string') {
        throw new Error('Invalid Likes API URL in configuration');
    }
    if (!config.dislikesApiUrl || typeof config.dislikesApiUrl !== 'string') {
        throw new Error('Invalid Dislikes API URL in configuration');
    }
    // Add more validation checks as needed
}

const CACHE_DURATION = 5000; // Cache duration in milliseconds (1 minute)
let cachedDashboardData = null;
let lastFetchTime = 0;

app.get('/api/dashboard', async (req, res) => {
    if (!config.apiUrl) {
        return res.status(400).send('API URL not set. Please set your Rumble API URL in the dashboard.');
    }

    const currentTime = Date.now();
    // Check if cached data is still valid
    if (cachedDashboardData && (currentTime - lastFetchTime < CACHE_DURATION)) {
        return res.json(cachedDashboardData);
    }

    try {
        const response = await axios.get(config.apiUrl);
        const data = response.data;

        const followerCount = data.followers?.num_followers || 0;
        const subscriberCount = data.subscribers?.num_subscribers || 0;

        // Cache the new data
        cachedDashboardData = {
            followers: followerCount,
            subscribers: subscriberCount,
            goals: config.goals || {},
            options: config.options || {}
        };
        lastFetchTime = currentTime;

        res.json(cachedDashboardData);
    } catch (error) {
        console.error('Error fetching data from Rumble API:', error.message);
        console.error(error.response ? error.response.data : error);
        res.status(500).send('Error fetching data');
    }
});


// In-memory storage for user accounts
const users = {}; // userId -> { username, email, password, rumbleApiKey }

// Endpoint to fetch data for the dashboard
app.get('/api/dashboard', async (req, res) => {
    if (!config.apiUrl) {
        return res.status(400).send('API URL not set. Please set your Rumble API URL in the dashboard.');
    }

    try {
        const response = await axios.get(config.apiUrl);
        const data = response.data;

        const followerCount = data.followers?.num_followers || 0;
        const subscriberCount = data.subscribers?.num_subscribers || 0;

        res.json({
            followers: followerCount,
            subscribers: subscriberCount,
            goals: config.goals || {},
            options: config.options || {}
        });
    } catch (error) {
        console.error('Error fetching data from Rumble API:', error.message);
        console.error(error.response ? error.response.data : error);
        res.status(500).send('Error fetching data');
    }
});

// New endpoint to fetch likes
app.get('/api/likes', async (req, res) => {
    if (!config.likesApiUrl) {
        return res.status(400).send('Likes API URL not set. Please set your Rumble API URL in the dashboard.');
    }

    try {
        const response = await axios.get(config.likesApiUrl);
        const data = response.data;

        res.json({
            likes: data.likes || 0
        });
    } catch (error) {
        console.error('Error fetching likes data from Rumble API:', error.message);
        console.error(error.response ? error.response.data : error);
        res.status(500).send('Error fetching likes data');
    }
});

// New endpoint to fetch dislikes
app.get('/api/dislikes', async (req, res) => {
    if (!config.dislikesApiUrl) {
        return res.status(400).send('Dislikes API URL not set. Please set your Rumble API URL in the dashboard.');
    }

    try {
        const response = await axios.get(config.dislikesApiUrl);
        const data = response.data;

        res.json({
            dislikes: data.dislikes || 0
        });
    } catch (error) {
        console.error('Error fetching dislikes data from Rumble API:', error.message);
        console.error(error.response ? error.response.data : error);
        res.status(500).send('Error fetching dislikes data');
    }
});

// Endpoint to get the current configuration
app.get('/api/config', (req, res) => {
    res.json(config);
});

// Endpoint to update the configuration
app.post('/api/update-config', (req, res) => {
    const newConfig = req.body;
    try {
        fs.writeFileSync('config.json', JSON.stringify(newConfig, null, 2));
        config = newConfig; // Update the in-memory config
        res.json({ success: true, message: 'Configuration updated successfully!' });
    } catch (error) {
        console.error('Error updating configuration:', error.message);
        res.status(500).json({ success: false, message: 'Error updating configuration' });
    }
});

// Serve the dashboard UI
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'dashboardui.html'));
});

// Serve the yourplans page
app.get('/yourplans', (req, res) => {
    res.sendFile(path.join(__dirname, '/', 'yourplans.html'));
});

// Endpoint to create a new user account
app.post('/create-account', (req, res) => {
    const { username, email, password, rumbleApiKey } = req.body;
    
    if (!username || !email || !password || !rumbleApiKey) {
        return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    // Create a unique ID for the user
    const userId = crypto.randomBytes(16).toString('hex');
    users[userId] = { username, email, password, rumbleApiKey };

    res.json({ success: true, userId });
});

// Serve the user dashboard based on user ID
app.get('/dashboard.html', (req, res) => {
    const userId = req.query.id;
    if (users[userId]) {
        res.sendFile(path.join(__dirname, '/', 'dashboard.html'));
    } else {
        res.status(404).send('Dashboard not found.');
    }
});

// Serve the account creation page
app.get('/myaccount', (req, res) => {
    res.sendFile(path.join(__dirname, '/', 'myaccount.html'));
});

// Function to get the server's IP address
function getServerIP() {
    const networkInterfaces = os.networkInterfaces();
    for (let interfaceKey in networkInterfaces) {
        const networkInterface = networkInterfaces[interfaceKey];
        for (let i = 0; i < networkInterface.length; i++) {
            const address = networkInterface[i];
            if (address.family === 'IPv4' && !address.internal) {
                return address.address; // Return the external IP address
            }
        }
    }
    return 'localhost'; // Fallback to localhost if no external IP is found
}

// Serve the followers goal UI
app.get('/followers', (req, res) => {
    res.sendFile(path.join(__dirname, 'widgets', 'followers.html'));
});

// Serve the subscribers goal UI
app.get('/subscribers', (req, res) => {
    res.sendFile(path.join(__dirname, 'widgets', 'subscribers.html'));
});

// Serve the likes goal UI
app.get('/likes', (req, res) => {
    res.sendFile(path.join(__dirname, 'widgets', 'likes.html'));
});

// Serve the dislikes goal UI
app.get('/dislikes', (req, res) => {
    res.sendFile(path.join(__dirname, 'widgets', 'dislikes.html'));
});


// Endpoint to clear the API URL
app.post('/api/clear-api-url', (req, res) => {
    if (!config.apiUrl) {
        return res.status(400).send('API URL is already cleared.');
    }
    
    try {
        config.apiUrl = ''; // Clear the API URL
        fs.writeFileSync('config.json', JSON.stringify(config, null, 2)); // Save the updated config
        res.send('API URL cleared successfully!');
    } catch (error) {
        console.error('Error clearing API URL:', error.message);
        res.status(500).send('Error clearing API URL');
    }
});

// Serve static files
app.use(express.static('public'));

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
