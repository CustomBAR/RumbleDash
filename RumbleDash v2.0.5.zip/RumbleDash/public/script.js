async function fetchDashboardData() {
    try {
        const response = await fetch('/api/dashboard');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();

        // Update follower and subscriber counts
        document.getElementById('followerCount').innerText = data.followers || 0;
        document.getElementById('subscriberCount').innerText = data.subscribers || 0;

        // Update progress bars
        const followerProgress = document.getElementById('followerProgress');
        const subscriberProgress = document.getElementById('subscriberProgress');

        const followerGoal = data.goals.followers || 100; // Default to 100 if not set
        const subscriberGoal = data.goals.subscribers || 100; // Default to 100 if not set

        const followerPercentage = (data.followers / followerGoal) * 100;
        const subscriberPercentage = (data.subscribers / subscriberGoal) * 100;

        followerProgress.style.width = `${followerPercentage}%`;
        subscriberProgress.style.width = `${subscriberPercentage}%`;

        // Hide counters if disabled in config
        if (!data.options.showFollowers) {
            document.getElementById('followerCounter').style.display = 'none';
        }
        if (!data.options.showSubscribers) {
            document.getElementById('subscriberCounter').style.display = 'none';
        }
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
    }
}
